import express from 'express';
import mongoose from 'mongoose';
import User from '../models/User.js';
import Order from '../models/Order.js';

const router = express.Router();

// GET /api/users -> Fetch all users
router.get('/', async (req, res) => {
    try {
        const users = await User.find().sort({ createdAt: -1 });
        
        // Map to expected format
        const mappedUsers = users.map(u => ({
            id: u.userId || u._id.toString(), // fallback
            name: `${u.firstName} ${u.lastName}`.trim() || u.name,
            email: u.email,
            phone: u.mobile || u.phone,
            totalOrders: u.totalOrders,
            totalSpending: u.totalSpending,
            points: u.points || 0,
            status: u.status,
            address: 'Not available currently', // Can be enhanced later
            joinedDate: new Date(u.createdAt).toISOString().split('T')[0]
        }));
        res.status(200).json(mappedUsers);
    } catch (err) {
        res.status(500).json({ message: 'Error fetching users', error: err.message });
    }
});

// GET /api/users/:id -> Fetch single user details + recent orders
router.get('/:id', async (req, res) => {
    try {
        const user = await User.findOne({ 
            $or: [{ userId: req.params.id }, { _id: mongoose.isValidObjectId(req.params.id) ? req.params.id : null }]
        });
        
        if (!user) return res.status(404).json({ message: 'User not found' });

        // Fetch recent orders. Order uses customer email or phone. Link by email
        const orders = await Order.find({ phone: user.mobile }).sort({ createdAt: -1 }).limit(10);
        
        const mappedUser = {
            id: user.userId || user._id.toString(),
            name: `${user.firstName} ${user.lastName}`.trim() || user.name,
            email: user.email,
            phone: user.mobile || user.phone,
            totalOrders: user.totalOrders,
            totalSpending: user.totalSpending,
            points: user.points || 0,
            status: user.status,
            address: 'Not available currently',
            joinedDate: new Date(user.createdAt).toISOString().split('T')[0],
            recentOrders: orders.map(o => ({
                orderId: o.orderId,
                productName: o.productName,
                totalPrice: o.totalPrice,
                status: o.status,
                createdAt: o.createdAt,
                customerName: o.customerName,
                phone: o.phone,
                address: o.address,
                firstName: o.firstName,
                lastName: o.lastName,
                customerEmail: o.customerEmail,
                phone: o.phone,
                streetAddress: o.streetAddress,
                streetAddress2: o.streetAddress2,
                city: o.city,
                state: o.state,
                postcode: o.postcode,
                companyName: o.companyName,
                gstNumber: o.gstNumber,
                quantity: o.quantity || 1,
                paymentMethod: o.paymentMethod || 'COD',
                paymentStatus: o.paymentStatus || 'Pending'
            }))
        };

        res.status(200).json(mappedUser);
    } catch (err) {
        res.status(500).json({ message: 'Error fetching user details', error: err.message });
    }
});

// POST /api/users -> Create user test endpoint
router.post('/', async (req, res) => {
    try {
        const newUser = new User(req.body);
        await newUser.save();
        res.status(201).json(newUser);
    } catch (err) {
        res.status(500).json({ message: 'Failed to create user', error: err.message });
    }
});

// PUT /api/users/:id -> Block/Unblock
router.put('/:id', async (req, res) => {
    try {
        const { status } = req.body;
        const queryId = req.params.id;
        
        console.log(`Trying to update user status for ID: ${queryId} to ${status}`);
        
        // Build query based on whether it is a MongoDB ObjectId or a custom USR-id
        const query = mongoose.isValidObjectId(queryId) 
            ? { $or: [{ userId: queryId }, { _id: queryId }] }
            : { userId: queryId };
            
        const user = await User.findOneAndUpdate(
            query,
            { $set: { status: status } },
            { new: true, runValidators: true }
        );
        
        if (!user) {
            console.warn(`User not found with ID: ${queryId}`);
            return res.status(404).json({ message: 'User not found in system' });
        }
        
        console.log(`User status updated successfully for ${user.email}`);
        res.status(200).json({ 
            success: true, 
            id: user.userId || user._id.toString(),
            status: user.status 
        });
    } catch (err) {
        console.error('Error in PUT /api/users/:id:', err);
        res.status(500).json({ message: 'Internal Server Error while blocking user', error: err.message });
    }
});

export default router;
