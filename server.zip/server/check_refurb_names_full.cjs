const mongoose = require('mongoose');
const uri = "mongodb://admin:Rachit12@ac-kxdsipc-shard-00-00.m8mypwk.mongodb.net:27017,ac-kxdsipc-shard-00-01.m8mypwk.mongodb.net:27017,ac-kxdsipc-shard-00-02.m8mypwk.mongodb.net:27017/3dprinter?ssl=true&replicaSet=atlas-u6vim9-shard-0&authSource=admin&retryWrites=true&w=majority";

const productSchema = new mongoose.Schema({
  name: String,
  condition: String,
});

const Product = mongoose.model('Product', productSchema);

async function check() {
    try {
        await mongoose.connect(uri);
        const p = await Product.find({ name: /refurb/i, condition: { $ne: "Refurbished" } }, "name");
        console.log('Count:', p.length);
        console.log('Products:', JSON.stringify(p.map(x => x.name), null, 2));
        process.exit(0);
    } catch (e) {
        process.exit(1);
    }
}
check();
