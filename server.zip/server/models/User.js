import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const userSchema = new mongoose.Schema({
  userId: { type: String, unique: true, sparse: true },
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  mobile: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  status: { type: String, enum: ["Active", "Blocked"], default: "Active" },
  totalOrders: { type: Number, default: 0 },
  totalSpending: { type: Number, default: 0 },
  wishlist: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Product' }],
  cart: [{
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    quantity: { type: Number, default: 1 }
  }],
  role: { type: String, default: 'user' },
  points: { type: Number, default: 0 },
  address: {
    streetAddress: { type: String },
    streetAddress2: { type: String },
    city: { type: String },
    state: { type: String },
    postcode: { type: String },
    country: { type: String, default: 'India' }
  },
  companyName: { type: String },
  gstNumber: { type: String }
}, { timestamps: true });

userSchema.pre('save', async function() {
  if (this.isNew && !this.userId) {
    const count = await mongoose.model('User').countDocuments();
    this.userId = `USR-${(count + 1).toString().padStart(3, '0')}`;
  }
  if (!this.isModified('password')) return;
  this.password = await bcrypt.hash(this.password, 10);
});

const User = mongoose.model('User', userSchema);
export default User;
